/**
 * Lanonasis REST API Client
 * Thin wrapper around fetch for Supabase REST endpoints and Edge Functions
 */

export interface ApiClientConfig {
  baseUrl: string;              // e.g., https://api.lanonasis.com/api/v1
  supabaseFunctionsUrl: string; // e.g., https://lanonasis.supabase.co/functions/v1
  apiKey?: string;
  bearerToken?: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: Array<{ field: string; message: string }>;
  };
}

export class LanonasisApiClient {
  private baseUrl: string;
  private functionsUrl: string;
  private apiKey?: string;
  private bearerToken?: string;

  constructor(config: ApiClientConfig) {
    this.baseUrl = config.baseUrl.replace(/\/$/, '');
    this.functionsUrl = config.supabaseFunctionsUrl.replace(/\/$/, '');
    this.apiKey = config.apiKey;
    this.bearerToken = config.bearerToken;
  }

  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.apiKey) {
      headers['X-API-Key'] = this.apiKey;
    } else if (this.bearerToken) {
      headers['Authorization'] = `Bearer ${this.bearerToken}`;
    }

    return headers;
  }

  async get<T>(path: string, params?: Record<string, string | number | boolean>): Promise<ApiResponse<T>> {
    const url = new URL(`${this.baseUrl}${path}`);
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, String(value));
        }
      });
    }

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return response.json() as Promise<ApiResponse<T>>;
  }

  async post<T>(path: string, body?: unknown): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: body ? JSON.stringify(body) : undefined,
    });

    return response.json() as Promise<ApiResponse<T>>;
  }

  async put<T>(path: string, body?: unknown): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: body ? JSON.stringify(body) : undefined,
    });

    return response.json() as Promise<ApiResponse<T>>;
  }

  async delete<T>(path: string): Promise<ApiResponse<T>> {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });

    return response.json() as Promise<ApiResponse<T>>;
  }

  // Memory endpoints
  memories = {
    list: (params?: { limit?: number; offset?: number; type?: string; tags?: string; sortBy?: string; sortOrder?: string }) =>
      this.get('/memories', params as Record<string, string | number>),

    create: (data: { title: string; content: string; type: string; tags?: string[]; metadata?: Record<string, unknown> }) =>
      this.post('/memories', data),

    get: (id: string) =>
      this.get(`/memories/${id}`),

    update: (id: string, data: { title?: string; content?: string; type?: string; tags?: string[]; metadata?: Record<string, unknown> }) =>
      this.put(`/memories/${id}`, data),

    delete: (id: string) =>
      this.delete(`/memories/${id}`),

    search: (data: { query: string; type?: string; threshold?: number; limit?: number }) =>
      this.post('/memories/search', data),
  };

  // Documentation search
  docs = {
    search: (data: { query: string; section?: string; limit?: number }) =>
      this.post('/docs/search', data),
  };

  // API Key endpoints
  apiKeys = {
    list: (params?: { active_only?: boolean; project_id?: string }) =>
      this.get('/auth/api-keys', params as Record<string, string | boolean>),

    create: (data: { name: string; description?: string; access_level?: string; expires_in_days?: number; project_id?: string }) =>
      this.post('/auth/api-keys', data),

    delete: (keyId: string) =>
      this.delete(`/auth/api-keys/${keyId}`),

    rotate: (keyId: string) =>
      this.post(`/auth/api-keys/${keyId}/rotate`),

    revoke: (keyId: string) =>
      this.post(`/auth/api-keys/${keyId}/revoke`),
  };

  // Project endpoints
  projects = {
    list: (params?: { organization_id?: string }) =>
      this.get('/projects', params as Record<string, string>),

    create: (data: { name: string; description?: string; organization_id?: string }) =>
      this.post('/projects', data),
  };

  // Organization endpoints
  organizations = {
    get: (orgId: string) =>
      this.get(`/organizations/${orgId}`),
  };

  // System endpoints
  system = {
    health: () =>
      this.get('/health'),

    authStatus: () =>
      this.get('/auth/status'),

    getConfig: (key: string) =>
      this.get('/config', { key }),

    setConfig: (key: string, value: string) =>
      this.put('/config', { key, value }),
  };

  // ==========================================================================
  // Supabase Edge Functions (Direct)
  // ==========================================================================

  private async callFunction<T>(functionName: string, method: 'GET' | 'POST', data?: unknown, params?: Record<string, string>): Promise<ApiResponse<T>> {
    const url = new URL(`${this.functionsUrl}/${functionName}`);
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, value);
        }
      });
    }

    const response = await fetch(url.toString(), {
      method,
      headers: this.getHeaders(),
      body: data ? JSON.stringify(data) : undefined,
    });

    return response.json() as Promise<ApiResponse<T>>;
  }

  // Memory Edge Functions (additional tools)
  memoryFunctions = {
    stats: () =>
      this.callFunction('memory-stats', 'GET'),

    bulkDelete: (ids: string[]) =>
      this.callFunction('memory-bulk-delete', 'POST', { ids }),
  };

  // Intelligence Edge Functions (6 tools)
  intelligence = {
    healthCheck: () =>
      this.callFunction('intelligence-health-check', 'GET'),

    suggestTags: (data: { memory_id: string; user_id: string; max_suggestions?: number; include_existing_tags?: boolean }) =>
      this.callFunction('intelligence-suggest-tags', 'POST', data),

    findRelated: (data: { memory_id: string; user_id: string; limit?: number; similarity_threshold?: number }) =>
      this.callFunction('intelligence-find-related', 'POST', data),

    detectDuplicates: (data: { user_id: string; similarity_threshold?: number; max_pairs?: number }) =>
      this.callFunction('intelligence-detect-duplicates', 'POST', data),

    extractInsights: (data: { user_id: string; topic?: string; memory_type?: string; max_memories?: number }) =>
      this.callFunction('intelligence-extract-insights', 'POST', data),

    analyzePatterns: (data: { user_id: string; time_range_days?: number }) =>
      this.callFunction('intelligence-analyze-patterns', 'POST', data),
  };
}

// Singleton instance
let apiClient: LanonasisApiClient | null = null;

export function initializeApiClient(config: ApiClientConfig): LanonasisApiClient {
  apiClient = new LanonasisApiClient(config);
  return apiClient;
}

export function getApiClient(): LanonasisApiClient {
  if (!apiClient) {
    throw new Error('API client not initialized. Call initializeApiClient() first.');
  }
  return apiClient;
}
