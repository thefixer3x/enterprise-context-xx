# Lanonasis Unified MCP Server

A thin MCP wrapper around Lanonasis Supabase REST APIs and Edge Functions. 27 tools, 3 prompts, and 2 resources for Memory, Intelligence, API Keys, Projects, Organizations, and System management.

## Architecture

```
Claude/Cursor → MCP Protocol → Unified MCP Server → REST API / Edge Functions → Supabase
```

The MCP server is a **thin protocol adapter** - all business logic lives in Supabase.

## Features

- **27 Tools** with full annotations (readOnlyHint, destructiveHint, idempotentHint, openWorldHint)
- **3 Prompts** for guided workflows (memory management, API key security, intelligence features)
- **2 Resources** for documentation and configuration access
- **Full metadata** including description, homepage URL, and icons
- **Parameter descriptions** on all tool inputs

## Tools (27 total)

### Memory (7)
- `list_memories` - List with pagination and filters
- `create_memory` - Create with vector embedding
- `get_memory` - Get by ID
- `update_memory` - Update existing
- `delete_memory` - Delete by ID
- `search_memories` - Semantic vector search
- `search_lanonasis_docs` - Search documentation

### Intelligence (6) - AI-Powered Analysis
- `intelligence_health_check` - Check intelligence service status
- `intelligence_suggest_tags` - AI-powered tag suggestions for memories
- `intelligence_find_related` - Find semantically related memories
- `intelligence_detect_duplicates` - Detect potential duplicate memories
- `intelligence_extract_insights` - Extract actionable insights from memories
- `intelligence_analyze_patterns` - Analyze usage patterns and trends

### Memory Utilities (2)
- `memory_stats` - Get memory usage statistics
- `memory_bulk_delete` - Delete multiple memories at once

### API Keys (5)
- `list_api_keys` - List user's keys
- `create_api_key` - Create new key
- `delete_api_key` - Delete permanently
- `rotate_api_key` - Rotate secret
- `revoke_api_key` - Deactivate

### Projects (2)
- `list_projects` - List org projects
- `create_project` - Create project

### Organizations (1)
- `get_organization_info` - Get org details

### System (4)
- `get_health_status` - System health
- `get_auth_status` - Auth status
- `get_config` - Get config
- `set_config` - Set config

## Prompts (3)

Interactive workflow guides for common operations:

- `memory_workflow` - Guided memory management (create, search, organize, analyze)
- `api_key_management` - API key security best practices
- `intelligence_guide` - AI-powered memory analysis features

## Resources (2)

- `docs://api-reference` - Complete API documentation
- `config://current` - Current server configuration

## Quick Start

```bash
# Install
npm install

# Configure
cp .env.example .env
# Edit .env with your API key

# Run stdio mode (for Claude Desktop)
npm run dev:stdio

# Run HTTP mode (for web/API access)
npm run dev:http
```

## Claude Desktop Config

```json
{
  "mcpServers": {
    "lanonasis": {
      "command": "node",
      "args": ["/path/to/unified-mcp-server/dist/index.js"],
      "env": {
        "LANONASIS_API_KEY": "lms_live_your_key"
      }
    }
  }
}
```

## HTTP Mode

When running with `--http`:

- Health: `GET http://localhost:3010/health`
- MCP: `POST http://localhost:3010/mcp`

## License

MIT
