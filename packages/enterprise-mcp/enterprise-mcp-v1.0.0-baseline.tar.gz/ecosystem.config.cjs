/**
 * PM2 Ecosystem Configuration
 *
 * Usage:
 *   pm2 start ecosystem.config.cjs
 *   pm2 start ecosystem.config.cjs --only lanonasis-mcp
 *   pm2 reload ecosystem.config.cjs --update-env
 */

module.exports = {
  apps: [
    {
      // Main MCP Server (HTTP/SSE mode)
      name: "lanonasis-mcp",
      script: "dist/index.js",
      args: "--http",
      cwd: __dirname,

      // Environment
      env: {
        NODE_ENV: "production",
        PORT: 3010,
        LANONASIS_API_URL: "https://api.lanonasis.com/api/v1",
        SUPABASE_FUNCTIONS_URL: "https://lanonasis.supabase.co/functions/v1",
        // LANONASIS_API_KEY set via pm2 start --env or .env file
      },

      // Process management
      instances: 1,              // Single instance for MCP (stateful connections)
      exec_mode: "fork",         // Fork mode (not cluster) for SSE/WebSocket
      autorestart: true,
      watch: false,
      max_memory_restart: "256M",

      // Logs
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      error_file: "logs/error.log",
      out_file: "logs/out.log",
      merge_logs: true,

      // Graceful shutdown
      kill_timeout: 5000,
      wait_ready: true,
      listen_timeout: 10000,
    },
  ],
};
